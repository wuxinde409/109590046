package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;

public class GameMap implements GameObject {
    private MovingBitmap blue;
    private MovingBitmap green;
    private Character _basic;
    private Enemy _enemy;
    private Evil _evil;
    private Stone _stone;
    private int[][] arr = {
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 0, 1, 2, 2},
            {2, 2, 2, 0, 0, 3, 0, 0, 2, 2},
            {2, 2, 2, 0, 3, 0, 3, 2, 2, 2},
            {2, 2, 0, 0, 2, 2, 2, 2, 2, 2},
            {2, 2, 0, 4, 0, 0, 4, 0, 2, 2},
            {2, 2, 0, 4, 0, 4, 0, 0, 9, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};
    private final int X = 145;
    private final int Y = 17;
    private final int MW = 34;
    private final int MH = 34;
    private int walk=23, x=1, y=7;

    public GameMap(){
        blue = new MovingBitmap(R.drawable.blue);
        blue.resize(34,34);
        green = new MovingBitmap(R.drawable.green);
        green.resize(34,34);
        for(int i = 0; i<arr.length;i++){
            for(int j = 0;j<arr.length;j++){
                if(arr[i][j]==1){
                    _basic.setLocation(X+i*MW,Y+j*MH);
                }
            }
        }
    }

    public void up() {
        walk -= 1;
        arr[x][y] = 0;
        if (arr[x - 1][y] == 3) {
            if (arr[x - 2][y] == 2 || arr[x - 2][y] == 4) {
                arr[x - 1][y] = 0;
            } else {
                arr[x - 1][y] = arr[x - 2][y];
                arr[x - 2][y] = arr[x - 1][y];
            }
        } else if (arr[x - 1][y] == 4) {
            if (arr[x - 2][y] == 0) {
                arr[x - 1][y] = arr[x - 2][y];
                arr[x - 2][y] = arr[x - 1][y];
            } else if (arr[x - 1][y] == 0) {
                x -= 1;
            }
        }
    }
    public void down() {
        walk -= 1;
        arr[x][y] = 0;
        if (arr[x + 1][y] == 3) {
            if (arr[x + 2][y] == 2 || arr[x + 2][y] == 4) {
                arr[x + 1][y] = 0;
            } else {
                arr[x + 1][y] = arr[x + 2][y];
                arr[x + 2][y] = arr[x + 1][y];
            }
        } else if (arr[x + 1][y] == 4) {
            if (arr[x + 2][y] == 0) {
                arr[x + 1][y] = arr[x + 2][y];
                arr[x + 2][y] = arr[x + 1][y];
            } else if (arr[x + 1][y] == 0) {
                x += 1;
            }
        }
    }
    public void left() {
        walk -= 1;
        arr[x][y] = 0;
        if(arr[x][y-1] == 3) {
            if (arr[x][y - 2] == 2 || arr[x][y - 2] == 4) {
                arr[x][y - 1] = 0;
            } else {
                arr[x][y - 1] = arr[x][y - 2];
                arr[x][y - 2] = arr[x][y - 1];
            }
        }
        else if(arr[x][y-1] == 4) {
            if (arr[x][y - 2] == 0) {
                arr[x][y - 1] = arr[x][y - 2];
                arr[x][y - 2] = arr[x][y - 1];
            }
        }
        else if(arr[x][y-1] == 0){
            y -= 1;
        }
    }
    public void right() {
        walk -= 1;
        arr[x][y] = 0;
        if(arr[x][y+1] == 3) {
            if (arr[x][y + 2] == 2 || arr[x][y + 2] == 4) {
                arr[x][y + 1] = 0;
            } else {
                arr[x][y + 1] = arr[x][y + 2];
                arr[x][y + 2] = arr[x][y + 1];
            }
        }
        else if(arr[x][y+1] == 4) {
            if (arr[x][y + 2] == 0) {
                arr[x][y + 1] = arr[x][y + 2];
                arr[x][y + 2] = arr[x][y + 1];
            }
        }
        else if(arr[x][y+1] == 0){
            y += 1;
        }
    }

    @Override
    public void release(){
        blue.release();
        green.release();
        blue=null;
        green=null;
    }

    @Override
    public void move(){

    }

    @Override
    public void show(){
        for(int i=0; i<4; i++){
            for (int j=0; j<6; j++){
                switch (arr[i][j]){
                    case 0:
                        break;
                    case 1:
                        blue.setLocation(X+(MW*j), Y+(MH*i));
                        blue.show();
                        break;
                    case 2:
                        green.setLocation(X+(MW*j), Y+(MH*i));
                        green.show();
                        break;
                    default:
                        break;
                }
            }
        }
    }
}

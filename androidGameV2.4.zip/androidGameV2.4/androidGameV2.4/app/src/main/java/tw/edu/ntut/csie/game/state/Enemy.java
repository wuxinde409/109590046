package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.extend.Animation;

public class Enemy implements GameObject {
    private Animation _enemy1;
    public Enemy(int x, int y){
        _enemy1 = new Animation();
        _enemy1.addFrame(R.drawable.enemy1);
        _enemy1.addFrame(R.drawable.enemy2);
        _enemy1.addFrame(R.drawable.enemy3_1);
        _enemy1.addFrame(R.drawable.enemy4);
        _enemy1.addFrame(R.drawable.enemy3_1);
        _enemy1.addFrame(R.drawable.enemy2);
        _enemy1.addFrame(R.drawable.enemy1);
        _enemy1.addFrame(R.drawable.enemy5);
        _enemy1.addFrame(R.drawable.enemy6);
        _enemy1.addFrame(R.drawable.enemy7);
        _enemy1.addFrame(R.drawable.enemy6);
        _enemy1.addFrame(R.drawable.enemy5);
        _enemy1.setDelay(1);
        _enemy1.setLocation(x,y);
    }

    @Override
    public void release(){
        _enemy1.release();
        _enemy1=null;
    }

    @Override
    public void move() {
        _enemy1.move();
    }

    @Override
    public void show(){
        _enemy1.show();
    }
}
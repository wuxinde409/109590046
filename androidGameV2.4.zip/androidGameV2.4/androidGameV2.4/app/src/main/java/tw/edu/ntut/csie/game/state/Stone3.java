package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Stone3 implements GameObject {
    private MovingBitmap _stone3;
    public Stone3(int x, int y){
        _stone3= new MovingBitmap(R.drawable.stone3);
        _stone3.setLocation(x,y);
    }

    @Override
    public void release(){
        _stone3.release();
        _stone3=null;
    }

    @Override
    public void move() {
        _stone3.move();
    }

    @Override
    public void show(){
        _stone3.show();
    }
}
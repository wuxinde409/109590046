package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.extend.Animation;

public class Evil implements GameObject {
    private Animation _Evil;

    public Evil(int x, int y){
        _Evil = new Animation();
        _Evil.addFrame(R.drawable.evil1);
        _Evil.addFrame(R.drawable.evil2);
        _Evil.addFrame(R.drawable.evil3);
        _Evil.addFrame(R.drawable.evil4);
        _Evil.addFrame(R.drawable.evil3);
        _Evil.addFrame(R.drawable.evil2);
        _Evil.addFrame(R.drawable.evil1);
        _Evil.addFrame(R.drawable.evil5);
        _Evil.addFrame(R.drawable.evil6);
        _Evil.addFrame(R.drawable.evil71);
        _Evil.addFrame(R.drawable.evil6);
        _Evil.addFrame(R.drawable.evil5);
        _Evil.setDelay(1);
        _Evil.setLocation(x,y);
    }

    public void setLocation(int x,int y){
        _Evil.setLocation(x,y);
    }

    @Override
    public void release(){
        _Evil.release();
        _Evil=null;
    }

    @Override
    public void move() {
        _Evil.move();
    }

    @Override
    public void show(){
        _Evil.show();
    }
}
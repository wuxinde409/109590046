package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Stone4 implements GameObject {
    private MovingBitmap _stone4;
    public Stone4(int x, int y){
        _stone4= new MovingBitmap(R.drawable.stone4);
        _stone4.setLocation(x,y);
    }

    @Override
    public void release(){
        _stone4.release();
        _stone4=null;
    }

    @Override
    public void move() {
        _stone4.move();
    }

    @Override
    public void show(){
        _stone4.show();
    }
}
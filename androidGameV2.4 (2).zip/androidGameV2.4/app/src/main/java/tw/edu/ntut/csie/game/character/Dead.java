package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Dead extends Base{
    public Dead (){
        _animation = new Animation();
        _animation.addFrame(R.drawable.dead1);
        _animation.addFrame(R.drawable.dead2);
        _animation.addFrame(R.drawable.dead3);
        _animation.addFrame(R.drawable.dead4);
        _animation.addFrame(R.drawable.dead5);
        _animation.addFrame(R.drawable.dead6);
        _animation.addFrame(R.drawable.dead7);
        _animation.addFrame(R.drawable.dead8);
        _animation.addFrame(R.drawable.dead9);
        _animation.addFrame(R.drawable.dead10);
        _animation.addFrame(R.drawable.dead11);
        _animation.addFrame(R.drawable.dead12);
        _animation.addFrame(R.drawable.dead13);
        _animation.addFrame(R.drawable.dead14);
        _animation.addFrame(R.drawable.dead15);
        _animation.addFrame(R.drawable.dead166);
    }

    public boolean isLastFrame() {
        return _animation.isLastFrame();
    }
    public void reset() {
        _animation.reset();
    }
    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+3, y-20);
        _x=x;
        _y=y;
    }
    public void inversion() {
        _animation.inversion();
    }
}

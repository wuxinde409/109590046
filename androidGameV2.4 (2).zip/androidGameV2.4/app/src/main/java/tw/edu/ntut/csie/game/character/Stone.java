package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.extend.Animation;

public class Stone extends Base{
    public Stone(int n){
        _animation=new Animation();
        if(n==0)
            _animation.addFrame(R.drawable.stone1);
        else if(n==1)
            _animation.addFrame(R.drawable.stone2);
        else if(n==2)
            _animation.addFrame(R.drawable.stone3);
        else if(n==3)
            _animation.addFrame(R.drawable.stone4);

    }

    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+3, y-4);
        _x=x;
        _y=y;
    }
}

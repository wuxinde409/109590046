package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.extend.Animation;

public class Enemy extends Base {
    public Enemy() {
        _animation = new Animation();
        _animation.addFrame(R.drawable.enemy1);
        _animation.addFrame(R.drawable.enemy2);
        _animation.addFrame(R.drawable.enemy3_1);
        _animation.addFrame(R.drawable.enemy4);
        _animation.addFrame(R.drawable.enemy3_1);
        _animation.addFrame(R.drawable.enemy2);
        _animation.addFrame(R.drawable.enemy1);
        _animation.addFrame(R.drawable.enemy5);
        _animation.addFrame(R.drawable.enemy6);
        _animation.addFrame(R.drawable.enemy7);
        _animation.addFrame(R.drawable.enemy6);
        _animation.addFrame(R.drawable.enemy5);

    }

    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+3, y-20);
        _x=x;
        _y=y;
    }
}

package tw.edu.ntut.csie.game.state;

import android.util.Log;

import java.util.List;
import java.util.Map;

import tw.edu.ntut.csie.game.Game;
import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.Pointer;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.character.Base;
import tw.edu.ntut.csie.game.character.Enemy;
import tw.edu.ntut.csie.game.character.Evil;
import tw.edu.ntut.csie.game.character.Kick;
import tw.edu.ntut.csie.game.character.MainCharcter;
import tw.edu.ntut.csie.game.character.Stone;
import tw.edu.ntut.csie.game.core.Audio;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.engine.GameEngine;
import tw.edu.ntut.csie.game.extend.Animation;
import tw.edu.ntut.csie.game.extend.BitmapButton;
import tw.edu.ntut.csie.game.extend.ButtonEventHandler;
import tw.edu.ntut.csie.game.extend.Integer;
public class StateRun extends AbstractGameState {
    public Open _open;
    public static final int DEFAULT_SCORE_DIGITS = 4;
    private Torch _torch;
    private Frame _frame;
    public int level=1;
    private int[][] arr = {
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 0, 1, 2, 2},
            {2, 2, 2, 0, 0, 3, 0, 0, 2, 2},
            {2, 2, 2, 0, 3, 0, 3, 2, 2, 2},
            {2, 2, 0, 0, 2, 2, 2, 2, 2, 2},
            {2, 2, 0, 4, 0, 0, 4, 0, 2, 2},
            {2, 2, 0, 4, 0, 4, 0, 0, 9, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};

    private int[][] arr1 ={
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 0, 0, 0, 0, 2, 2, 2},
            {2, 2, 2, 3, 2, 0, 0, 0, 0, 2},
            {2, 2, 0, 0, 2, 2, 4, 4, 4, 2},
            {2, 2, 0, 0, 2, 2, 0, 0, 0, 2},
            {2, 2, 1, 0, 2, 2, 0, 3, 0, 2},
            {2, 2, 2, 2, 2, 2, 9, 0, 3, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};

    private int[][] arr2 ={
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 1, 2, 0, 0, 4, 2, 2, 2, 2},
            {2, 0, 4, 0, 4, 0, 0, 0, 2, 2},
            {2, 4, 0, 4, 0, 4, 4, 0, 9, 2},
            {2, 0, 4, 0, 4, 0, 4, 4, 0, 2},
            {2, 2, 0, 4, 0, 4, 0, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};


    private int[][] arr3 ={

            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 2, 2, 0, 9, 2, 2, 2},
            {2, 2, 2, 2, 0, 0, 4, 0, 2, 2},
            {2, 2, 2, 2, 0, 0, 4, 0, 2, 2},
            {2, 2, 1, 2, 0, 0, 0, 0, 2, 2},
            {2, 2, 3, 2, 4, 4, 4, 4, 2, 2},
            {2, 2, 0, 0, 0, 0, 0, 0, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 0, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}

    };

    private int[][] arr4 ={
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
            {2, 2, 2, 0, 1, 0, 2, 2, 2, 2},
            {2, 2, 2, 4, 4, 4, 2, 2, 2, 2},
            {2, 2, 0, 0, 0, 0, 2, 2, 2, 2},
            {2, 2, 2, 0, 4, 0, 0, 2, 2, 2},
            {2, 2, 2, 3, 2, 4, 4, 0, 0, 2},
            {2, 2, 2, 0, 0, 4, 0, 3, 2, 2},
            {2, 2, 2, 2, 2, 2, 0, 4, 0, 2},
            {2, 2, 2, 2, 2, 2, 0, 9, 2, 2},
            {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}};








    private Base[][] obj;
    private final int X = 145;
    private final int Y = 17;
    private final int MW = 34;
    private final int MH = 34;
    private int walk=23, x=2, y=7, face=0, stcount=1, sp, kick=0;
    private BitmapButton _up;
    private BitmapButton _down;
    private BitmapButton _left;
    private BitmapButton _right;
    private MovingBitmap _background1,_background2,_background3,_background4,_background5;
    private MovingBitmap _lefttop;
    private MovingBitmap _leftdown;
    private MovingBitmap _righttop;
    private MovingBitmap _rightdown;
    private Kick _kick;
    private MainCharcter _maincharacter;
//    private MovingBitmap _cloud;

//    private MovingBitmap _message;

//    private Animation _flower;

//    private Integer _scores;
//    private boolean _grab;

//    private Audio _music;

    public StateRun(GameEngine engine) {
        super(engine);
    }

    @Override
    public void initialize(Map<String, Object> data) {
        initializeUp();
        initializeDown();
        initializeRight();
        initializeLeft();

        _open= new Open();
        _open.initialize();

        _torch= new Torch();
        _torch.initialize();

        _frame= new Frame();
        _frame.initialize();


        _background1 = new MovingBitmap(R.drawable.background1);
        _background2 = new MovingBitmap(R.drawable.background2);
        _background3 = new MovingBitmap(R.drawable.background3);
        _background3.setLocation(_background3.getX()-14,_background3.getY()+12);
        _background4 = new MovingBitmap(R.drawable.background4);
        _background4.setLocation(_background4.getX()-15,_background4.getY()+12);
        _background5 = new MovingBitmap(R.drawable.background5);


        double a =0.35;
        _background1.resize((int)(_background1.getWidth()*a),(int)(_background1.getHeight()*a));
        _background2.resize((int)(_background1.getWidth()),(int)(_background1.getHeight()));
        _background3.resize((int)(_background1.getWidth()),(int)(_background1.getHeight()));
        _background4.resize((int)(_background1.getWidth()),(int)(_background1.getHeight()));
        _background5.resize((int)(_background1.getWidth()),(int)(_background1.getHeight()));

        _background2.setVisible(false);
        _background3.setVisible(false);
        _background4.setVisible(false);
        _background5.setVisible(false);


        _lefttop = new MovingBitmap(R.drawable.digit_0);
        _lefttop.setLocation(0,0);
        _righttop = new MovingBitmap(R.drawable.righttop);
        _righttop.setLocation(513,0);
        _leftdown = new MovingBitmap(R.drawable.leftdown);
        _leftdown.setLocation(0,137);
        _rightdown = new MovingBitmap(R.drawable.rightdown);
        _rightdown.setLocation(463,137);

//        _scores = new Integer(DEFAULT_SCORE_DIGITS, 50, 550, 10);

//        _music = new Audio(R.raw.ntut);
//        _music.setRepeating(true);
//        _music.play();

//        _grab = false;
        obj=new Base[10][10];
        init();

    }

public void changebackground(){
        _open.reset();
        _maincharacter.setVisible(false);
        level++;
    if (level == 2) {
        _background2.setVisible(true);
        arr=arr1;
        x=6;
        y=2;
        init();
    }
    if (level == 3) {
        _background3.setVisible(true);
        arr=arr2;
        x=3;
        y=1;
        init();
    }
    if (level == 4) {
        _background4.setVisible(true);
        arr=arr3;
        x=5;
        y=2;
        init();
    }
    if (level == 5) {
        _background5.setVisible(true);
        arr=arr4;
        x=1;
        y=4;
        init();
    }



}
    public void init(){
        for(int i=0; i<10; i++){
            for(int j=0; j<10; j++){
                if(obj[i][j]!=null)
                    obj[i][j].setVisible(false);
                if(arr[i][j]==1){
                    MainCharcter c = new MainCharcter();
                    _maincharacter = c;
                    c.setLocation(X+(MW*j), Y+(MH*i));
                    obj[i][j]=c;
                    addGameObject(c);
                }
                else if(arr[i][j]==3){
                    Enemy e = new Enemy();
                    e.setLocation(X+(MW*j), Y+(MH*i));
                    obj[i][j]=e;
                    addGameObject(e);
                }
                else if(arr[i][j]==9){
                    Evil ev = new Evil();
                    ev.setLocation(X+(MW*j), Y+(MH*i));
                    obj[i][j]=ev;
                    addGameObject(ev);
                }
                else if(arr[i][j]==4){
                    Stone st =new Stone((int) (Math.random() * 4));
                    st.setLocation(X+(MW*j), Y+(MH*i));
                    obj[i][j]=st;
                    addGameObject(st);

                }
            }
        }
    }


    public void up() {
        walk -= 1;
        arr[x][y] = 0;
        if (arr[x - 1][y] == 3) {
            _maincharacter.kick();
            if (arr[x - 2][y] == 2 || arr[x - 2][y] == 4) {
                arr[x - 1][y] = 0;
                obj[x-1][y].setVisible(false);
                obj[x-1][y]=null;
            } else {
                sp=arr[x - 1][y];
                arr[x - 1][y] = arr[x - 2][y];
                arr[x - 2][y] = sp;
                obj[x-1][y].setLocation(obj[x-1][y].getX(),obj[x-1][y].getY()-MH);
                obj[x-2][y]=obj[x-1][y];
                obj[x-1][y]=null;
            }
        } else if (arr[x - 1][y] == 4) {
            _maincharacter.kick();
            if (arr[x - 2][y] == 0) {
                sp=arr[x - 1][y];
                arr[x - 1][y] = arr[x - 2][y];
                arr[x - 2][y] = sp;
                obj[x-1][y].setLocation(obj[x-1][y].getX(),obj[x-1][y].getY()-MH);
                obj[x-2][y]=obj[x-1][y];
                obj[x-1][y]=null;
            }
        } else if (arr[x - 1][y] == 0) {
            arr[x - 1][y]=1;
            obj[x][y].setLocation(obj[x][y].getX(),obj[x][y].getY()-MH);
            obj[x-1][y]=obj[x][y];
            obj[x][y]=null;
            x -= 1;
        }
        if (arr[x+1][y]==9 || arr[x-1][y]==9 || arr[x][y+1]==9 || arr[x][y-1]==9) {
            changebackground();
        }
    }
    public void down() {
        walk -= 1;
        arr[x][y] = 0;
        if (arr[x + 1][y] == 3) {
            _maincharacter.kick();
            if (arr[x + 2][y] == 2 || arr[x + 2][y] == 4) {
                arr[x + 1][y] = 0;
                obj[x + 1][y].setVisible(false);
                obj[x + 1][y] = null;
            } else {
                sp = arr[x + 1][y];
                arr[x + 1][y] = arr[x + 2][y];
                arr[x + 2][y] = sp;
                obj[x + 1][y].setLocation(obj[x + 1][y].getX(), obj[x + 1][y].getY() + MH);
                obj[x + 2][y] = obj[x + 1][y];
                obj[x + 1][y] = null;
            }
        } else if (arr[x + 1][y] == 4) {
            _maincharacter.kick();
            if (arr[x + 2][y] == 0) {
                sp = arr[x + 1][y];
                arr[x + 1][y] = arr[x + 2][y];
                arr[x + 2][y] = sp;
                obj[x + 1][y].setLocation(obj[x + 1][y].getX(), obj[x + 1][y].getY() + MH);
                obj[x + 2][y] = obj[x + 1][y];
                obj[x + 1][y] = null;
            }
        } else if (arr[x + 1][y] == 0) {
            arr[x + 1][y] = 1;
            obj[x][y].setLocation(obj[x][y].getX(), obj[x][y].getY() + MH);
            obj[x + 1][y] = obj[x][y];
            obj[x][y] = null;
            x += 1;
        }
        if (arr[x + 1][y] == 9 || arr[x - 1][y] == 9 || arr[x][y + 1] == 9 || arr[x][y - 1] == 9) {
            changebackground();
        }
    }
    public void left() {
        walk -= 1;
        arr[x][y] = 0;
        if(face == 0){
            obj[x][y].inversion();
            face=1;
        }
        if(arr[x][y-1] == 3) {
            _maincharacter.kick();
            if (arr[x][y - 2] == 2 || arr[x][y - 2] == 4) {
                arr[x][y - 1] = 0;
                obj[x][y-1].setVisible(false);
                obj[x][y-1]=null;
            } else {
                sp=arr[x][y-1];
                arr[x][y - 1] = arr[x][y - 2];
                arr[x][y - 2] = sp;
                obj[x][y-1].setLocation(obj[x][y-1].getX()-MW,obj[x][y-1].getY());
                obj[x][y-2]=obj[x][y-1];
                obj[x][y-1]=null;
            }
        }
        else if(arr[x][y-1] == 4) {
            _maincharacter.kick();
            if (arr[x][y - 2] == 0) {
                sp=arr[x][y-1];
                arr[x][y - 1] = arr[x][y - 2];
                arr[x][y - 2] = sp;
                obj[x][y-1].setLocation(obj[x][y-1].getX()-MW,obj[x][y-1].getY());
                obj[x][y-2]=obj[x][y-1];
                obj[x][y-1]=null;
            }
        }
        else if(arr[x][y-1] == 0){
            arr[x][y-1]=1;
            obj[x][y].setLocation(obj[x][y].getX()-MW,obj[x][y].getY());
            obj[x][y-1]=obj[x][y];
            obj[x][y]=null;
            y -= 1;

        }
        if (arr[x+1][y]==9 || arr[x-1][y]==9 || arr[x][y+1]==9 || arr[x][y-1]==9) {
            changebackground();
        }
    }
    public void right() {
        walk -= 1;
        arr[x][y] = 0;
        if(face == 1){
            obj[x][y].inversion();
            face=0;
        }
        if(arr[x][y+1] == 3) {
            _maincharacter.kick();
            if (arr[x][y + 2] == 2 || arr[x][y + 2] == 4) {
                arr[x][y + 1] = 0;
                obj[x][y+1].setVisible(false);
                obj[x][y+1]=null;
            } else {
                sp=arr[x][y+1];
                arr[x][y + 1] = arr[x][y + 2];
                arr[x][y + 2] = sp;
                obj[x][y+1].setLocation(obj[x][y+1].getX()+MW,obj[x][y+1].getY());
                obj[x][y+2]=obj[x][y+1];
                obj[x][y+1]=null;
            }
        }
        else if(arr[x][y+1] == 4) {
            _maincharacter.kick();
            if (arr[x][y + 2] == 0) {
                sp=arr[x][y+1];
                arr[x][y + 1] = arr[x][y + 2];
                arr[x][y + 2] = sp;
                obj[x][y+1].setLocation(obj[x][y+1].getX()+MW,obj[x][y+1].getY());
                obj[x][y+2]=obj[x][y+1];
                obj[x][y+1]=null;
            }
        }
        else if(arr[x][y+1] == 0){
            arr[x][y+1]=1;
            obj[x][y].setLocation(obj[x][y].getX()+MW,obj[x][y].getY());
            obj[x][y+1]=obj[x][y];
            obj[x][y]=null;
            y += 1;
        }
        if (arr[x+1][y]==9 || arr[x-1][y]==9 || arr[x][y+1]==9 || arr[x][y-1]==9) {
            changebackground();
        }
    }
    public void initializeUp(){
        _up = new BitmapButton(R.drawable.up,58,250);
        addGameObject(_up);
        _up.addButtonEventHandler(button -> {
            up();
        });
        addPointerEventHandler(_up);
    }
    public void initializeDown(){
        _down = new BitmapButton(R.drawable.down,58,310);
        addGameObject(_down);
        _down.addButtonEventHandler(button -> {
            down();
        });
        addPointerEventHandler(_down);
    }
   public void initializeRight(){
      _right = new BitmapButton(R.drawable.right,93,280);
     addGameObject(_right);
     _right.addButtonEventHandler(button -> {
         right();
       });
       addPointerEventHandler(_right);
    }
    public void initializeLeft(){
        _left = new BitmapButton(R.drawable.left,23,280);
        addGameObject(_left);
       _left.addButtonEventHandler(button -> {
           left();
       });
       addPointerEventHandler(_left);
   }



    @Override
    public void move() {
        moveAllGameObjects();
        _frame.move();
        _open.move();
//      _flower.move();
//      Log.d("d","dd");
    }

    @Override
    public void show() {
        _background1.show();
        _background2.show();
        _background3.show();
        _background4.show();
        _background5.show();
        showAllGameObjects();
        _lefttop.show();
        _righttop.show();
        _leftdown.show();
        _rightdown.show();
//        _scores.show();
//        _flower.show();
       // _torch.show();
       // _frame.show();
        _up.show();
        _down.show();
        _right.show();
        _left.show();
        _open.show();
    }

    @Override
    public void release() {
        _open.release();
        _background1.release();
        _background2.release();
        _background3.release();
        _background4.release();
        _background5.release();

        _lefttop.release();
        _righttop.release();
        _leftdown.release();
        _rightdown.release();
//        _scores.release();
//        _flower.release();
//        _music.release();
        _torch.release();
        _frame.release();
        _up.release();
        _down.release();
        _right.release();
        _left.release();
        _lefttop=null;
        _righttop=null;
        _leftdown=null;
        _rightdown=null;
        _torch=null;
        _frame=null;
        _background1 = null;
        _background2 = null;
        _background3 = null;
        _background4 = null;
        _background5 = null;

        _up=null;
        _down=null;
        _left=null;
        _right=null;
        _open = null;

//        _scores = null;
//        _flower = null;
//        _music = null;
    }

    @Override
    public void keyPressed(int keyCode) {
        // TODO Auto-generated method stub
    }

    @Override
    public void keyReleased(int keyCode) {
        // TODO Auto-generated method stub
    }

    @Override
    public void orientationChanged(float pitch, float azimuth, float roll) {
//        if (roll > 15 && roll < 60 && _cx > 50)
//            _cx -= 2;
//        if (roll < -15 && roll > -60 && _cx + _cloud.getWidth() < 500)
//            _cx += 2;
    }

    @Override
    public void accelerationChanged(float dX, float dY, float dZ) {
        // TODO Auto-generated method stub
    }

//    @Override
//    public boolean pointerPressed(Pointer actionPointer, List<Pointer> pointers) {
////        _message.setVisible(false);
//        return true;
//    }
//
//    @Override
//    public boolean pointerMoved(Pointer actionPointer, List<Pointer> pointers) {
//        return false;
//    }
//
//    public void resizeAndroidIcon() {
//
//    }
//
//    @Override
//    public boolean pointerReleased(Pointer actionPointer, List<Pointer> pointers) {
////        _grab = false;
//        return false;
//    }

    @Override
    public void pause() {
        //_music.pause();
    }

    @Override
    public void resume() {
        //_music.resume();
    }
}

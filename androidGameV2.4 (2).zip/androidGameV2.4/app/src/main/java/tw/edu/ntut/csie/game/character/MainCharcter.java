package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class MainCharcter extends Base{
    private Kick _kick;
    private int state=0;
    private boolean visible = true;
    public MainCharcter (){
        _kick = new Kick();
        _animation = new Animation();
        _animation.setRepeating(true);
        _animation.addFrame(R.drawable.basic1);
        _animation.addFrame(R.drawable.basic2);
        _animation.addFrame(R.drawable.basic3);
        _animation.addFrame(R.drawable.basic4);
        _animation.addFrame(R.drawable.basic3);
        _animation.addFrame(R.drawable.basic2);
        _animation.addFrame(R.drawable.basic1);
        _animation.addFrame(R.drawable.basic5);
        _animation.addFrame(R.drawable.basic6);
        _animation.addFrame(R.drawable.basic7);
        _animation.addFrame(R.drawable.basic6);
        _animation.addFrame(R.drawable.basic5);
    }

    @Override
    public void move() {
        if(visible==false){
            return;
        }
        if(state == 0){
            _animation.setVisible(true);
            _kick.setVisible(false);
            _animation.move();
        }else{
            if(_kick.isLastFrame()){
                _kick.reset();
            }
            _animation.setVisible(false);
            _kick.setVisible(true);
            _kick.move();
        }
        if(_kick.isLastFrame() && state==1){
            state=0;
        }
    }

    @Override
    public void setVisible(boolean visible) {
        this.visible = visible;
        super.setVisible(visible);
    }

    @Override
    public void show() {
        super.show();
        _kick.show();
    }

    public void kick(){
        state=1;
    }

    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+3, y-20);
        _kick.setLocation(x+3,y);
        _x=x;
        _y=y;
    }
    public void inversion() {
        _animation.inversion();
        _kick.inversion();
    }
}

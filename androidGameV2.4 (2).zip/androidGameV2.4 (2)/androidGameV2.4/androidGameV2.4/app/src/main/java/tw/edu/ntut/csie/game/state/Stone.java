package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Stone implements GameObject {
    private MovingBitmap _stone1;
    public Stone(int x, int y){
        _stone1= new MovingBitmap(R.drawable.stone1);
        _stone1.setLocation(x,y);
    }

    @Override
    public void release(){
        _stone1.release();
        _stone1=null;
    }

    @Override
    public void move() {
        _stone1.move();
    }

    @Override
    public void show(){
        _stone1.show();
    }
}
package tw.edu.ntut.csie.game.state;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Stone2 implements GameObject {
    private MovingBitmap _stone2;
    public Stone2(int x, int y){
        _stone2= new MovingBitmap(R.drawable.stone2);
        _stone2.setLocation(x,y);
    }

    @Override
    public void release(){
        _stone2.release();
        _stone2=null;
    }

    @Override
    public void move() {
        _stone2.move();
    }

    @Override
    public void show(){
        _stone2.show();
    }
}
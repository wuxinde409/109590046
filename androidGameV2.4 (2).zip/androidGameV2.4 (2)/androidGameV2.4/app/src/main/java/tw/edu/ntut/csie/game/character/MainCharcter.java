package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class MainCharcter extends Base{
    private Kick _kick;
    private Dead _dead;
    private int state=0;
    private boolean visible = true;
    public MainCharcter (){
        _kick = new Kick();
        _dead = new Dead();
        _animation = new Animation();
        _animation.setRepeating(true);
        _animation.addFrame(R.drawable.basic1);
        _animation.addFrame(R.drawable.basic2);
        _animation.addFrame(R.drawable.basic3);
        _animation.addFrame(R.drawable.basic4);
        _animation.addFrame(R.drawable.basic3);
        _animation.addFrame(R.drawable.basic2);
        _animation.addFrame(R.drawable.basic1);
        _animation.addFrame(R.drawable.basic5);
        _animation.addFrame(R.drawable.basic6);
        _animation.addFrame(R.drawable.basic7);
        _animation.addFrame(R.drawable.basic6);
        _animation.addFrame(R.drawable.basic5);
    }

    @Override
    public void move() {
        if(visible==false){
            return;
        }
        if(state == 0){
            _animation.setVisible(true);
            _kick.setVisible(false);
            _dead.setVisible(false);
            _animation.move();
        }else if(state == 1){
            if(_kick.isLastFrame()){
                _kick.reset();
            }
            _animation.setVisible(false);
            _kick.setVisible(true);
            _dead.setVisible(false);
            _kick.move();
        }
        else{
            if(_dead.isLastFrame()){
                _dead.reset();
            }
            _animation.setVisible(false);
            _dead.setVisible(true);
            _kick.setVisible(false);
            _dead.move();
        }
        if(_kick.isLastFrame() && state==1){
            state=0;
        }
        if(_dead.isLastFrame() && state==2){
            state=0;
        }
    }
    public boolean dying(){
        return !_dead.isLastFrame();
    }
    @Override
    public void setVisible(boolean visible) {
        this.visible = visible;
        _kick.setVisible(visible);
        _dead.setVisible(visible);
        super.setVisible(visible);
    }

    @Override
    public void show() {
        super.show();
        _kick.show();
        _dead.show();
    }

    public void kick(){
        state=1;
    }
    public void Dead(){
        state=2;
    }

    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+3, y-20);
        _kick.setLocation(x+3,y);
        _dead.setLocation(x+3,y);
        _x=x;
        _y=y;
    }
    public void inversion() {
        _animation.inversion();
        _kick.inversion();
    }
}
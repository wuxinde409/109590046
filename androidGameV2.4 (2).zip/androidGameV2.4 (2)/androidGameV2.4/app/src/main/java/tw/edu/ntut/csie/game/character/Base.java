package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.GameObject;
import tw.edu.ntut.csie.game.extend.Animation;

public class Base implements GameObject {
    public Object inver;
    protected Animation _animation;
    protected int _x,_y;

    @Override
    public void move() {
        _animation.move();
    }

    @Override
    public void show() {
        _animation.show();

    }

    @Override
    public void release() {
        _animation.release();

    }

    public void setLocation(int x, int y) {
        _animation.setLocation(x, y);
    }

    public void inversion() {
        _animation.inversion();
    }

    public int getX(){
       return  _x;

    }
    public int getY(){
       return _y;
    }
    public void setVisible(boolean visible){
        _animation.setVisible(visible);
    }
}

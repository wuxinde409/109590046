package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Dead extends Base{
    private MovingBitmap _black;
    public Dead (){
        _black = new MovingBitmap(R.drawable.black);
        _black.setLocation(0,0);
        _animation = new Animation();
        _animation.addFrame(R.drawable.dead1);
        _animation.addFrame(R.drawable.dead2);
        _animation.addFrame(R.drawable.dead3);
        _animation.addFrame(R.drawable.dead4);
        _animation.addFrame(R.drawable.dead5);
        _animation.addFrame(R.drawable.dead6);
        _animation.addFrame(R.drawable.dead7);
        _animation.addFrame(R.drawable.dead8);
        _animation.addFrame(R.drawable.dead9);
        _animation.addFrame(R.drawable.dead10);
        _animation.addFrame(R.drawable.dead11);
        _animation.addFrame(R.drawable.dead12);
        _animation.addFrame(R.drawable.dead13);
        _animation.addFrame(R.drawable.dead14);
        _animation.addFrame(R.drawable.dead15);
        _animation.addFrame(R.drawable.dead16);
    }

    @Override
    public void setVisible(boolean visible) {
        _black.setVisible(visible);
        super.setVisible(visible);
    }

    public boolean isFrame(){
        return _animation.getCurrentFrameIndex()<_animation.getFrameCount();
    }
    public boolean isLastFrame() {
        return _animation.isLastFrame();
    }
    public void reset() {
        _animation.reset();
    }

    @Override
    public void move() {
        super.move();
    }

    @Override
    public void show() {
        _black.show();
        super.show();
    }

    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x-38, y-120);
        _x=x;
        _y=y;
    }
    public void inversion() {
        _animation.inversion();
    }
}
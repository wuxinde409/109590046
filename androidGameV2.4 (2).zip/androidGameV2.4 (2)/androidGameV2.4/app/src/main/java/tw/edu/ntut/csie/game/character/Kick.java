package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.core.MovingBitmap;
import tw.edu.ntut.csie.game.extend.Animation;

public class Kick extends Base{
    public Kick (){
        _animation = new Animation();
        _animation.addFrame(R.drawable.kick1);
        _animation.addFrame(R.drawable.kick2);
        _animation.addFrame(R.drawable.kick3);
        _animation.addFrame(R.drawable.kick4);
        _animation.addFrame(R.drawable.kick5);
        _animation.addFrame(R.drawable.kick6);
        _animation.addFrame(R.drawable.kick7);
        _animation.addFrame(R.drawable.kick8);
        _animation.addFrame(R.drawable.kick9999);
    }

    public boolean isLastFrame() {
        return _animation.isLastFrame();
    }
    public void reset() {
        _animation.reset();
    }
    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+3, y-20);
        _x=x;
        _y=y;
    }
    public void inversion() {
        _animation.inversion();
    }
}
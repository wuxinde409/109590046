package tw.edu.ntut.csie.game.character;

import tw.edu.ntut.csie.game.R;
import tw.edu.ntut.csie.game.extend.Animation;

public class Evil extends Base{
    public Evil(){
        _animation = new Animation();
        _animation.addFrame(R.drawable.evil1);
        _animation.addFrame(R.drawable.evil2);
        _animation.addFrame(R.drawable.evil3);
        _animation.addFrame(R.drawable.evil4);
        _animation.addFrame(R.drawable.evil3);
        _animation.addFrame(R.drawable.evil2);
        _animation.addFrame(R.drawable.evil1);
        _animation.addFrame(R.drawable.evil5);
        _animation.addFrame(R.drawable.evil6);
        _animation.addFrame(R.drawable.evil71);
        _animation.addFrame(R.drawable.evil6);
        _animation.addFrame(R.drawable.evil5);
    }

    @Override
    public void setLocation(int x, int y) {
        super.setLocation(x+4, y-5);
        _x=x;
        _y=y;
    }
}
